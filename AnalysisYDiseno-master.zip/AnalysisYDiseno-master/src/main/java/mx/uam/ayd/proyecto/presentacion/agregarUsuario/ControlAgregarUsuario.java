package mx.uam.ayd.proyecto.presentacion.agregarUsuario;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mx.uam.ayd.proyecto.negocio.ServicioSupervisor;
import mx.uam.ayd.proyecto.negocio.ServicioTrabajador;
import mx.uam.ayd.proyecto.negocio.modelo.Supervisor;

/**
 * 
 * Módulo de control para la historia de usuario AgregarUsuario
 * 
 * @author ADDIG Tech
 *
 */
@Component
public class ControlAgregarUsuario {
	
	@Autowired
	private ServicioTrabajador servicioUsuario;
	
	@Autowired
	private ServicioSupervisor servicioSupervisor;
	
	@Autowired
	private VentanaAgregarUsuario ventana;
	
	/**
	 * Inicia la historia de usuario
	 * 
	 */
	public void inicia() {
		
		List <Supervisor> grupos = servicioSupervisor.recuperaSupervisores();
		
		ventana.muestra(this, grupos);
		
	}

	public void agregaUsuario(String nombre, String apellido, String supervisor,String correo) {
 
		try {
			servicioUsuario.agregaUsuario(nombre, apellido, supervisor,correo);
			ventana.muestraDialogoConMensaje("Usuario agregado exitosamente");
		} catch(Exception ex) {
			ventana.muestraDialogoConMensaje("Error al agregar usuario: "+ex.getMessage());
		}
		
		termina();
		
	}
	
	/**
	 * Termina la historia de usuario
	 * 
	 */
	public void termina() {
		ventana.setVisible(false);		
	}

}
