package mx.uam.ayd.proyecto.presentacion.agregarSupervisor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mx.uam.ayd.proyecto.negocio.ServicioSupervisor;

@Component
public class ControlAgregarSupervisor {


	@Autowired
	private ServicioSupervisor servicioSupervisor;
	
	@Autowired
	private VentanaAgregarSupervisor ventana;
	
	public void inicia() {
		ventana.muestra(this);
		
	}

	public void agregaUsuario(String nombre, String contrasena) {
 
		try {
			servicioSupervisor.agregaUsuario(nombre, contrasena);
			ventana.muestraDialogoConMensaje("Usuario agregado exitosamente");
		} catch(Exception ex) {
			ventana.muestraDialogoConMensaje("Error al agregar usuario: "+ex.getMessage());
		}
		
		termina();
		
	}
	
	/**
	 * Termina la historia de usuario
	 * 
	 */
	public void termina() {
		ventana.setVisible(false);		
	}
	

	
}
