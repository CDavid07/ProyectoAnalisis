package mx.uam.ayd.proyecto.presentacion.sesionTrabajador;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.springframework.stereotype.Component;

import mx.uam.ayd.proyecto.negocio.modelo.Trabajador;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


@SuppressWarnings("serial")
@Component
public class ventanaSesiontrabajador extends JFrame{
	
	private JPanel contentPane;
	@SuppressWarnings("unused")
	private ControlsesionTrabajador control;
	
	public ventanaSesiontrabajador() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 349, 351);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNombre = new JLabel("Ventana Trabajador");
		lblNombre.setBounds(10, 11, 80, 16);
		contentPane.add(lblNombre);
		
		JButton btnNewButton = new JButton("Ver Actividades");
		btnNewButton.setBounds(104, 60, 139, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Ver registro de actividades");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(53, 226, 234, 23);
		contentPane.add(btnNewButton_1);
		
		
	}
	
	public void muestra(ControlsesionTrabajador contr, Trabajador trabajador) {
		
		this.control = contr;
		JLabel lblNew = new JLabel(trabajador.getNombre());
		lblNew.setBounds(139, 148, 46, 14);
		contentPane.add(lblNew);	
		setVisible(true);
	}
}
