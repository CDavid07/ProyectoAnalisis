package mx.uam.ayd.proyecto.presentacion.agregarSupervisor;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.springframework.stereotype.Component;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

@SuppressWarnings("serial")
@Component
public class VentanaAgregarSupervisor extends JFrame{
	
	private JPanel contentPane;
	private ControlAgregarSupervisor control;
	private JTextField textFieldNombre;
	private JTextField textFieldContrasena;
	
	
	
public VentanaAgregarSupervisor() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 349, 351);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(28, 39, 80, 16);
		contentPane.add(lblNombre);
		
		JLabel lblContrasena = new JLabel("Contraseña:");
		lblContrasena.setBounds(28, 84, 61, 16);
		contentPane.add(lblContrasena);
		

		textFieldNombre = new JTextField();
		textFieldNombre.setBounds(92, 34, 186, 26);
		contentPane.add(textFieldNombre);
		textFieldNombre.setColumns(10);
		
		textFieldContrasena = new JTextField();
		textFieldContrasena.setBounds(92, 79, 186, 26);
		contentPane.add(textFieldContrasena);
		textFieldContrasena.setColumns(10);
		
		JButton btnAgregar = new JButton("Agregar");
		
		btnAgregar.setBounds(43, 255, 117, 29);
		contentPane.add(btnAgregar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				control.termina();
			}
		});
		btnCancelar.setBounds(182, 255, 117, 29);
		contentPane.add(btnCancelar);
		
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textFieldNombre.getText().equals("") || textFieldContrasena.getText().equals("")) {
					muestraDialogoConMensaje("El nombre y la contraseña no deben estar vacios");
				} else {
					control.agregaUsuario(textFieldNombre.getText(), textFieldContrasena.getText());
				}
			}
		});
		
}

public void muestra(ControlAgregarSupervisor control) {
	
	this.control = control;
	
	textFieldNombre.setText("");

	textFieldContrasena.setText("");
	
	setVisible(true);

}

public void muestraDialogoConMensaje(String mensaje ) {
	JOptionPane.showMessageDialog(this , mensaje);
}
}
