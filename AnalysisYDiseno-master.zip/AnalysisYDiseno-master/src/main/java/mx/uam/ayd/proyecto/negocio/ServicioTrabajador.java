package mx.uam.ayd.proyecto.negocio;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.uam.ayd.proyecto.datos.SupervisorRepository;
import mx.uam.ayd.proyecto.datos.TrabajadorRepository;
import mx.uam.ayd.proyecto.negocio.modelo.Supervisor;
import mx.uam.ayd.proyecto.negocio.modelo.Trabajador;

@Slf4j
@Service
public class ServicioTrabajador {
	
	@Autowired 
	private TrabajadorRepository trabajadorRepository;
	
	@Autowired
	private SupervisorRepository supervisorRepository;
	/**
	 * 
	 * Permite agregar a un usuario
	 * 
	 * @param nombre
	 * @param contrasena
	 * @param supervisor
	 * 
	 * @return
	 */
	
public void agregaUsuario(String nombre, String contrasena, String supervisor, String correo) {
		
		// Regla de negocio: No se permite agregar dos usuarios con el mismo nombre y apellido
		
		
		Trabajador usuario = trabajadorRepository.findByNombreAndContrasena(nombre, contrasena);
		
		if(usuario != null) {
			throw new IllegalArgumentException("Ese usuario ya existe");
		}
		
		Supervisor grupo = supervisorRepository.findByNombre(supervisor);
		
		if(grupo == null) {
			throw new IllegalArgumentException("No se encontró el grupo");
		}
		
		log.info("Agregando usuario nombre: "+nombre+" apellido:"+contrasena);
		
		usuario = new Trabajador();
		usuario.setNombre(nombre);
		usuario.setContrasena(contrasena);
		usuario.setCorreo(correo);
		
		trabajadorRepository.save(usuario);
		
		grupo.addTrabajador(usuario); 
		
		
		supervisorRepository.save(grupo);
		

	}

	public List <Trabajador> recuperaUsuarios() {

		
		
		List <Trabajador> usuarios = new ArrayList<>();
		
		for(Trabajador usuario:trabajadorRepository.findAll()) {
			usuarios.add(usuario);
		}
				
		return usuarios;
	}

	
	public Trabajador buscarUsuario(String nombre, String contrasena) {
		Trabajador usuario = trabajadorRepository.findByNombreAndContrasena(nombre, contrasena);
		if(usuario == null) 
			return null;
		else
			return usuario;
			
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	public void ingresaSupervisor(String nombre, String contrasena) {
		
		// Regla de negocio: No se permite agregar dos usuarios con el mismo nombre y apellido
		
		
		Supervisor usuario = TrabajadorRepository.findByNombreAndContrasena(nombre, contrasena);
		
		if(usuario != null) {
			throw new IllegalArgumentException("Este usuario ya existe");
		}
		
		
		log.info("Agregado usuario nombre: "+nombre+" contrasena:"+ contrasena);
		
		usuario = new Supervisor();
		usuario.setNombre(nombre);
		usuario.setContrasena(contrasena);
		
		TrabajadorRepository.save(usuario);		

	}
	
	public Supervisor validaSupervisor(String nombre, String contrasena) {
		Supervisor usuario = TrabajadorRepository.findByNombreAndContrasena(nombre, contrasena);
		
		if(usuario != null) {
			throw new IllegalArgumentException("No existe");
		} else {
			if(validaContrasena(contrasena) == true){
				return usuario;
			}
		}
	}
	
	public boolean validaContrasena (String contrasena) {
		Supervisor usuario = TrabajadorRepository.findByContrasena(contrasena);
		
		if(usuario.getContrasena().equals(contrasena)) {
			return true;
		} else {
			return false;
		}
		
	}
		
	public List <Trabajador> recuperaUsuarios() {

		
		
		List <Trabajador> usuarios = new ArrayList<>();
		
		for(Trabajador usuario:TrabajadorRepository.findAll()) {
			usuarios.add(usuario);
		}
				
		return usuarios;
	}
	
	*/

}
