package mx.uam.ayd.proyecto.presentacion.iniciarsesion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.springframework.stereotype.Component;

import mx.uam.ayd.proyecto.negocio.modelo.Trabajador;
import mx.uam.ayd.proyecto.presentacion.sesionTrabajador.ControlsesionTrabajador;

@SuppressWarnings("serial")
@Component
public class VentanaIniciarsesion extends JFrame{
	
	private JPanel contentPane;
	private Controliniciarsesion control;
	private ControlsesionTrabajador control2;
	private JTextField textFieldNombre;
	private JTextField textFieldContrasena;
	
public VentanaIniciarsesion() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 349, 351);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(28, 39, 80, 16);
		contentPane.add(lblNombre);
		
		JLabel lblContrasena = new JLabel("Contraseña:");
		lblContrasena.setBounds(28, 84, 61, 16);
		contentPane.add(lblContrasena);
		
		textFieldNombre = new JTextField();
		textFieldNombre.setBounds(92, 34, 186, 26);
		contentPane.add(textFieldNombre);
		textFieldNombre.setColumns(10);
		
		textFieldContrasena = new JTextField();
		textFieldContrasena.setBounds(92, 79, 186, 26);
		contentPane.add(textFieldContrasena);
		textFieldContrasena.setColumns(10);
		
		JButton btnIniciar = new JButton("Iniciar");
		btnIniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Trabajador uni=	control.buscarTrabajador(textFieldNombre.getText(), textFieldContrasena.getText());
					control2.inicia(uni);
			}
		});
		btnIniciar.setBounds(43, 255, 117, 29);
		contentPane.add(btnIniciar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				control.termina();
			}
		});
		btnCancelar.setBounds(182, 255, 117, 29);
		contentPane.add(btnCancelar);
		
		
}

public void muestra(Controliniciarsesion control) {
	
	this.control = control;
	
	textFieldNombre.setText("");

	textFieldContrasena.setText("");
	
	setVisible(true);

}

public void muestraDialogoConMensaje(String mensaje ) {
	JOptionPane.showMessageDialog(this , mensaje);
}
}
