package mx.uam.ayd.proyecto.datos;

import org.springframework.data.repository.CrudRepository;

import mx.uam.ayd.proyecto.negocio.modelo.Supervisor;

/**
 * Repositorio para Grupos
 * 
 * @author ADDIG Tech
 *
 */
public interface SupervisorRepository extends CrudRepository <Supervisor, Long> {
	
	public Supervisor findByNombre(String nombre);
	
	public Supervisor findByNombreAndContrasena(String nombre, String contrasena);
}
