package mx.uam.ayd.proyecto.presentacion.iniciarsesion;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mx.uam.ayd.proyecto.negocio.ServicioSupervisor;
import mx.uam.ayd.proyecto.negocio.ServicioTrabajador;
import mx.uam.ayd.proyecto.negocio.modelo.Supervisor;
import mx.uam.ayd.proyecto.negocio.modelo.Trabajador;

@Component
public class Controliniciarsesion {

	@Autowired
	private ServicioTrabajador servicioUsuario;
	
	@Autowired
	private ServicioSupervisor servicioSupervisor;
	
	@Autowired
	private VentanaIniciarsesion ventana;
	
	public void inicia() {
				
		ventana.muestra(this);
		
	}
	public Trabajador buscarTrabajador(String nombre, String apellido) {
		 
			Trabajador us =servicioUsuario.buscarUsuario(nombre, apellido);
			if(us==null) 
				return null;
			else
				return us;
		
	}
	
	public Supervisor buscarSupervisor(String nombre, String apellido) {
		 
		Supervisor es =servicioSupervisor.buscarUsuario(nombre, apellido);
		if(es==null) 
			return null;
		else
			return es;
	}
	
	public void termina() {
		ventana.setVisible(false);		
	}
	
	
}
