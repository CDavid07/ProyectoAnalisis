package mx.uam.ayd.proyecto.negocio;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.uam.ayd.proyecto.datos.SupervisorRepository;
import mx.uam.ayd.proyecto.negocio.modelo.Supervisor;

@Slf4j
@Service
public class ServicioSupervisor {
	
	@Autowired 
	SupervisorRepository supervisorRepository;
	
	
	/**
	 * 
	 * Recupera todos los supervisores
	 * 
	 * @return
	 */
	
public void agregaUsuario(String nombre, String contrasena) {
		
		// Regla de negocio: No se permite agregar dos usuarios con el mismo nombre y apellido
		
		
		Supervisor usuario = supervisorRepository.findByNombreAndContrasena(nombre, contrasena);
		
		if(usuario != null) {
			throw new IllegalArgumentException("Ese usuario ya existe");
		}
		
		log.info("Agregando usuario nombre: "+nombre+" Contraseña:"+contrasena);
		
		usuario = new Supervisor();
		usuario.setNombre(nombre);
		usuario.setContrasena(contrasena);
		
		supervisorRepository.save(usuario);
		
		

	}

	public List <Supervisor> recuperaSupervisores() {

		List <Supervisor> grupos = new ArrayList<>();
		
		for(Supervisor grupo:supervisorRepository.findAll()) {
			grupos.add(grupo);
		}
				
		return grupos;
	}
	
	public Supervisor buscarUsuario(String nombre, String contrasena) {
		Supervisor usuario = supervisorRepository.findByNombreAndContrasena(nombre, contrasena);
		if(usuario == null) 
			return null;
		else
			return usuario;
			
	}

}
