package mx.uam.ayd.proyecto.presentacion.listarUsuarios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import mx.uam.ayd.proyecto.negocio.ServicioTrabajador;
import mx.uam.ayd.proyecto.negocio.modelo.Trabajador;

@Slf4j
@Component
public class ControlListarUsuarios {
	@Autowired
	private ServicioTrabajador servicioUsuario;

	public void inicia() {
		List <Trabajador> usuarios = servicioUsuario.recuperaUsuarios();
		
		for(Trabajador usuario:usuarios) {
			log.info("usuario: "+usuario);
		}
		
		
	}

}
