package mx.uam.ayd.proyecto.datos;

import org.springframework.data.repository.CrudRepository;

import mx.uam.ayd.proyecto.negocio.modelo.Trabajador;

/**
 * 
 * Repositorio para supervisor
 * 
 * @author ADDIG Tech
 *
 */
public interface TrabajadorRepository extends CrudRepository <Trabajador, Long> {
	
	public Trabajador findByNombreAndContrasena(String nombre, String contrasena);
	//public Trabajador findByContrasena(String contrasena);

}
