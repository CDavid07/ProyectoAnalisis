package mx.uam.ayd.proyecto.presentacion.sesionTrabajador;

import org.springframework.beans.factory.annotation.Autowired;

import mx.uam.ayd.proyecto.negocio.modelo.Trabajador;


public class ControlsesionTrabajador{
	
	
	@Autowired
	private ventanaSesiontrabajador ventana;
	
	public void inicia(Trabajador trabajador) {
		
		ventana.muestra(this, trabajador);
		
	}
	
	public void termina() {
		ventana.setVisible(false);		
	}
}
